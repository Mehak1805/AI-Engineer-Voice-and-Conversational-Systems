# okDriver Voice Assistant

Wake-word activated voice assistant prototype with:
- **Wake-word detection & STT:** Vosk (offline) or Google Cloud Speech-to-Text (multi-language)
- **Language support:** English, Hindi, Hinglish (English-India with code-mixing)
- **Free/optional LLM integration**
- **Offline TTS via pyttsx3**
- **Latency logging** for STT / LLM / TTS / total

## STT Backends

### Vosk (Recommended for offline/demo)
- **Languages:** English only
- **Setup:** Automatic (included in setup)
- **Run:** `python .\app.py --model .\vosk-model-en-us-0.22-lgraph`

### Google Cloud Speech-to-Text (Recommended for Hindi/Hinglish)
- **Languages:** 100+ including Hindi, English (India), Hinglish
- **Setup:** Requires Google Cloud credentials
- **Run:** `python .\app.py --stt-backend google --language hi-IN`

## One-command setup on Windows PowerShell
From the project root:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1
```

This will:
1. Create a virtual environment in `.venv`
2. Install `requirements.txt` (including google-cloud-speech)
3. Download and extract the Vosk model
4. Set `VOSK_MODEL_PATH` for the current PowerShell session

## Manual setup
If you already have the model in the workspace:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r .\requirements.txt
```

Set environment variable:
```powershell
$env:VOSK_MODEL_PATH = (Resolve-Path .\vosk-model-en-us-0.22-lgraph).Path
```

### Test the microphone first
Before running the full assistant, confirm the mic input works:

```powershell
python .\app.py --model $env:VOSK_MODEL_PATH --test-mic
```

If needed, choose a specific input device:

```powershell
python .\app.py --model $env:VOSK_MODEL_PATH --device 1
python .\app.py --model $env:VOSK_MODEL_PATH --device "Microphone Array"
```

### Demo mode (no voice input needed)
To see the full pipeline working with predefined queries:

```powershell
python .\app.py --model .\vosk-model-en-us-0.22-lgraph --demo
```

This will process 3 demo queries and print latency benchmarks. Great for testing without voice setup.

## Using Google Cloud Speech-to-Text for Hindi/Hinglish

### Step 1: Set up Google Cloud
1. Create a Google Cloud project: https://console.cloud.google.com
2. Enable Speech-to-Text API
3. Create a service account with "Editor" role
4. Download the service account key as JSON

### Step 2: Set credentials
```powershell
$env:GOOGLE_APPLICATION_CREDENTIALS = "C:\path\to\service-account-key.json"
```

### Step 3: Run with Google Cloud STT
```powershell
# Hindi
python .\app.py --stt-backend google --language hi-IN

# English (India) - best for Hinglish
python .\app.py --stt-backend google --language en-IN

# English (US)
python .\app.py --stt-backend google --language en-US
```

### Available language codes
- `en-US`: English (United States)
- `en-IN`: English (India) - **recommended for Hinglish**
- `hi-IN`: Hindi
- `gu-IN`: Gujarati
- `ta-IN`: Tamil
- `te-IN`: Telugu
- See full list: https://cloud.google.com/speech-to-text/docs/languages

### Optional LLM installs
Only install these if you want local generation or OpenAI support:

```powershell
pip install openai transformers torch
```

## Demo flow
Say:
- wake word: `ok driver`
- query: `kya haal chaal` (or "how are you")

The assistant will print:
- STT latency
- LLM latency
- TTS latency
- total latency

## Notes
- If you want faster startup and lower RAM usage, switch to `vosk-model-small-en-us-0.15`.
- If you want best accuracy and can afford the download, use `vosk-model-en-us-0.22`.
- The app works without API keys using a safe fallback response.
